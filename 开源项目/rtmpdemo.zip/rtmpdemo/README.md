# rtmpdemo
rtmpdump src fro librtmp
rtmpdemo same demo usd by librtmp